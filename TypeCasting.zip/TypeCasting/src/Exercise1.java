
public class Exercise1 {

	public static void main(String[] args) {
		
		int yearOne = 10;
		int yearTwo = 9;
		int yearThree = 8;
		int yearFour = 10;
		int yearFive = 9;
		
		
		float avgGrade = (yearOne + yearTwo + yearThree + yearFour + yearFive) / 5.0f;
		
		System.out.print(avgGrade);
		
		

	}

}
