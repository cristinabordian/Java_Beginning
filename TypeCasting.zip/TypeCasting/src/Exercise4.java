
public class Exercise4 {

	public static void main(String[] args) {
		
		double f = 1.2345678912345;
		 System.out.println(f);
		 
		 //Why the result is 1.2345679? 
		 // Answer: Float stores fractional numbers. It can only store up to 7 decimal digits.
		 
		 // Update code so the full number is shown in the console
		 // Answer if we change the variable to a double type, we should see the the number with all decimals.  
		// Double can store up to 15 decimals
		

	}

}
