
public class Exercise3 {

	public static void main(String[] args) {
		
		final int theoryHoursPass = 100; 
		final int successfulExercisesPass = 84; 
		final int certExamPass = 7; 
		
		
		int theoryHours = 100;
		int successfulExcercises = 75;
		int certExam = 8; 
		
		boolean ceritfied = true;
		//boolean notCertified = false; 
		
		if(theoryHours >= theoryHoursPass && successfulExcercises >= successfulExercisesPass && successfulExcercises >= certExamPass)
		{System.out.println("Certified true! You did it!");}
		else {System.out.println("Certified false! Study More!");}
		
		}
		
		
		
		
		
	}


