
public class DateVariablesApp {

	public static void main(String[] args) {
		
		int current_year  = 2019;
        byte current_month = 5;
        byte current_day   = 25;

 
        System.out.print("Today is: ");
        System.out.print( current_day );
        System.out.print("-");
        System.out.print( current_month );
        System.out.print("-");
        System.out.print( current_year );
        
        
        
    //  > Today is: 25-5-2019

		// Difference between print() & println()
        //In print() the output will be shown on the same line
        //In println() - the output will be shown on the next line
        
        
        //What other primitive data types we know besides int & byte?
        
        //Primitive data type:
        // byte
        // short
        // int
        // long
        // float
        // double
        //boolean
        // char
        
		

	}

}
