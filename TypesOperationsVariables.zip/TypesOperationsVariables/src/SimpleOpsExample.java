
public class SimpleOpsExample {

	public static void main(String[] args) {
		
		// (type)value - instructs machine to convert to this data type
		
		//types
		//operations
		//type casting - when Java converts a value from one data type to another data type
		//Conversion is done in a way so we don't lose any data. 
		// type safety
		//ex:
		//int/100 -> float/100.0
		//int/100 <- float/100.0 - from float to int there is data loss
		
		
		int a = 10;
		int b = 100; 
		int r = a + b;
		System.out.println("a + b = " + r);
		
		
		//When working with operators, we have to have the same data types 
		//Otherwise the Java machine will transform it for us
		// We can indicate how we want the data types converted 
		
		
		//ex: student grade
		int grade_1 = 10;
		int grade_2 = 10;
		int grade_3 = 8;
		
		//avg
		float avg = (grade_1 + grade_2 + grade_3 ) / (float)3; 
		
		System.out.println(avg);
		
		
		//
		float x = 1.0f;
		float y = (float)1; //these will have the same value in the memory
		// float y will take longer for JVM to process
		
		
		
		
		

	}

}
